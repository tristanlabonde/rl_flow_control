V35 :0x24 decomp_2d_fft$$d2d_fft_log
11 fft_log.f90 S624 0
06/25/2026  09:50:24
use iso_c_binding public 0 indirect
use iso_fortran_env public 0 indirect
use glassman public 0 indirect
use decomp_2d_fft public 0 direct
use factor public 0 indirect
use mpi public 0 indirect
use decomp_2d_constants public 0 direct
use decomp_2d_mpi public 0 direct
use decomp_2d public 0 direct
enduse
D 64 26 664 8 663 7
D 73 26 667 8 666 7
D 82 23 6 1 11 11 0 0 0 0 0
 0 11 11 11 11 11
D 85 23 6 1 11 11 0 0 0 0 0
 0 11 11 11 11 11
D 88 23 6 1 11 116 0 0 0 0 0
 0 116 11 11 116 116
D 91 23 6 1 11 116 0 0 0 0 0
 0 116 11 11 116 116
D 94 23 6 1 11 116 0 0 0 0 0
 0 116 11 11 116 116
D 97 23 6 1 11 116 0 0 0 0 0
 0 116 11 11 116 116
D 100 23 6 1 11 117 0 0 0 0 0
 0 117 11 11 117 117
D 103 23 6 1 11 117 0 0 0 0 0
 0 117 11 11 117 117
D 2776 26 8001 1936 8000 7
D 2881 22 7
D 2883 22 7
D 2885 22 7
D 2887 22 7
D 2889 22 7
D 2891 22 7
D 2893 22 7
D 2895 22 7
D 2897 22 7
D 2899 22 7
D 2901 22 7
D 2903 22 7
S 624 24 0 0 0 9 1 0 4986 10019 8000 A 0 0 0 0 B 10000 3 0 0 0 0 0 0 9503 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 decomp_2d_fft
S 626 24 0 0 0 9 1 0 5012 10005 8000 A 0 0 624 0 B 0 3 0 0 0 0 0 624 0 0 0 0 0 0 0 0 0 0 0 0 0 3 0 0 0 0 0 0 decomp_2d_fft$$d2d_fft_log
S 646 3 0 0 0 6 1 1 0 0 0 A 0 0 0 0 B 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6
S 647 3 0 0 0 6 1 1 0 0 0 A 0 0 0 0 B 0 0 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6
S 648 3 0 0 0 6 1 1 0 0 0 A 0 0 0 0 B 0 0 0 0 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6
R 663 25 7 iso_c_binding c_ptr
R 664 5 8 iso_c_binding val c_ptr
R 666 25 10 iso_c_binding c_funptr
R 667 5 11 iso_c_binding val c_funptr
R 701 6 45 iso_c_binding c_null_ptr$ac
R 703 6 47 iso_c_binding c_null_funptr$ac
R 704 26 48 iso_c_binding ==
R 706 26 50 iso_c_binding !=
S 738 3 0 0 0 7 1 1 0 0 0 A 0 0 0 0 B 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 7
S 739 3 0 0 0 7 1 1 0 0 0 A 0 0 0 0 B 0 0 0 0 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 7
R 742 7 3 iso_fortran_env character_kinds$ac
R 764 7 25 iso_fortran_env integer_kinds$ac
R 766 7 27 iso_fortran_env logical_kinds$ac
R 768 7 29 iso_fortran_env real_kinds$ac
S 7971 3 0 0 0 7 1 1 0 0 0 A 0 0 0 0 B 0 0 0 0 0 0 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 7
R 8000 25 19 decomp_2d decomp_info
R 8001 5 20 decomp_2d xst decomp_info
R 8002 5 21 decomp_2d xen decomp_info
R 8003 5 22 decomp_2d xsz decomp_info
R 8004 5 23 decomp_2d yst decomp_info
R 8005 5 24 decomp_2d yen decomp_info
R 8006 5 25 decomp_2d ysz decomp_info
R 8007 5 26 decomp_2d zst decomp_info
R 8008 5 27 decomp_2d zen decomp_info
R 8009 5 28 decomp_2d zsz decomp_info
R 8011 5 30 decomp_2d x1dist decomp_info
R 8012 5 31 decomp_2d x1dist$sd decomp_info
R 8013 5 32 decomp_2d x1dist$p decomp_info
R 8014 5 33 decomp_2d x1dist$o decomp_info
R 8016 5 35 decomp_2d y1dist decomp_info
R 8018 5 37 decomp_2d y1dist$sd decomp_info
R 8019 5 38 decomp_2d y1dist$p decomp_info
R 8020 5 39 decomp_2d y1dist$o decomp_info
R 8022 5 41 decomp_2d y2dist decomp_info
R 8024 5 43 decomp_2d y2dist$sd decomp_info
R 8025 5 44 decomp_2d y2dist$p decomp_info
R 8026 5 45 decomp_2d y2dist$o decomp_info
R 8028 5 47 decomp_2d z2dist decomp_info
R 8030 5 49 decomp_2d z2dist$sd decomp_info
R 8031 5 50 decomp_2d z2dist$p decomp_info
R 8032 5 51 decomp_2d z2dist$o decomp_info
R 8035 5 54 decomp_2d x1cnts decomp_info
R 8036 5 55 decomp_2d x1cnts$sd decomp_info
R 8037 5 56 decomp_2d x1cnts$p decomp_info
R 8038 5 57 decomp_2d x1cnts$o decomp_info
R 8040 5 59 decomp_2d y1cnts decomp_info
R 8042 5 61 decomp_2d y1cnts$sd decomp_info
R 8043 5 62 decomp_2d y1cnts$p decomp_info
R 8044 5 63 decomp_2d y1cnts$o decomp_info
R 8046 5 65 decomp_2d y2cnts decomp_info
R 8048 5 67 decomp_2d y2cnts$sd decomp_info
R 8049 5 68 decomp_2d y2cnts$p decomp_info
R 8050 5 69 decomp_2d y2cnts$o decomp_info
R 8052 5 71 decomp_2d z2cnts decomp_info
R 8054 5 73 decomp_2d z2cnts$sd decomp_info
R 8055 5 74 decomp_2d z2cnts$p decomp_info
R 8056 5 75 decomp_2d z2cnts$o decomp_info
R 8059 5 78 decomp_2d x1disp decomp_info
R 8060 5 79 decomp_2d x1disp$sd decomp_info
R 8061 5 80 decomp_2d x1disp$p decomp_info
R 8062 5 81 decomp_2d x1disp$o decomp_info
R 8064 5 83 decomp_2d y1disp decomp_info
R 8066 5 85 decomp_2d y1disp$sd decomp_info
R 8067 5 86 decomp_2d y1disp$p decomp_info
R 8068 5 87 decomp_2d y1disp$o decomp_info
R 8070 5 89 decomp_2d y2disp decomp_info
R 8072 5 91 decomp_2d y2disp$sd decomp_info
R 8073 5 92 decomp_2d y2disp$p decomp_info
R 8074 5 93 decomp_2d y2disp$o decomp_info
R 8076 5 95 decomp_2d z2disp decomp_info
R 8078 5 97 decomp_2d z2disp$sd decomp_info
R 8079 5 98 decomp_2d z2disp$p decomp_info
R 8080 5 99 decomp_2d z2disp$o decomp_info
A 15 2 0 0 0 6 646 0 0 0 15 0 0 0 0 0 0 0 0 0 0 0
A 17 2 0 0 0 6 647 0 0 0 17 0 0 0 0 0 0 0 0 0 0 0
A 19 2 0 0 0 6 648 0 0 0 19 0 0 0 0 0 0 0 0 0 0 0
A 70 1 0 0 0 64 701 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
A 73 1 0 0 0 73 703 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
A 116 2 0 0 0 7 738 0 0 0 116 0 0 0 0 0 0 0 0 0 0 0
A 117 2 0 0 0 7 739 0 0 0 117 0 0 0 0 0 0 0 0 0 0 0
A 120 1 0 1 0 82 742 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
A 126 1 0 3 0 88 764 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
A 132 1 0 3 0 94 766 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
A 136 1 0 5 0 100 768 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0
A 1350 2 0 0 0 7 7971 0 0 0 1350 0 0 0 0 0 0 0 0 0 0 0
Z
J 133 1 1
V 70 64 7 0
S 0 64 0 0 0
A 0 6 0 0 1 2 0
J 134 1 1
V 73 73 7 0
S 0 73 0 0 0
A 0 6 0 0 1 2 0
J 29 1 1
V 120 82 7 0
R 0 85 0 0
A 0 6 0 0 1 3 0
J 75 1 1
V 126 88 7 0
R 0 91 0 0
A 0 6 0 0 1 3 1
A 0 6 0 0 1 17 1
A 0 6 0 0 1 15 1
A 0 6 0 0 1 19 0
J 77 1 1
V 132 94 7 0
R 0 97 0 0
A 0 6 0 0 1 3 1
A 0 6 0 0 1 17 1
A 0 6 0 0 1 15 1
A 0 6 0 0 1 19 0
J 80 1 1
V 136 100 7 0
R 0 103 0 0
A 0 6 0 0 1 15 1
A 0 6 0 0 1 19 0
T 8000 2776 0 0 0 0
A 8013 7 2881 0 1 2 1
A 8012 7 0 1350 1 10 1
A 8019 7 2883 0 1 2 1
A 8018 7 0 1350 1 10 1
A 8025 7 2885 0 1 2 1
A 8024 7 0 1350 1 10 1
A 8031 7 2887 0 1 2 1
A 8030 7 0 1350 1 10 1
A 8037 7 2889 0 1 2 1
A 8036 7 0 1350 1 10 1
A 8043 7 2891 0 1 2 1
A 8042 7 0 1350 1 10 1
A 8049 7 2893 0 1 2 1
A 8048 7 0 1350 1 10 1
A 8055 7 2895 0 1 2 1
A 8054 7 0 1350 1 10 1
A 8061 7 2897 0 1 2 1
A 8060 7 0 1350 1 10 1
A 8067 7 2899 0 1 2 1
A 8066 7 0 1350 1 10 1
A 8073 7 2901 0 1 2 1
A 8072 7 0 1350 1 10 1
A 8079 7 2903 0 1 2 1
A 8078 7 0 1350 1 10 0
Z
