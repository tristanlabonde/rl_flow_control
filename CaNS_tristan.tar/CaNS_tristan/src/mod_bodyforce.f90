module mod_bodyforce
  use mod_types
  implicit none

contains

subroutine calc_bodyforce(n, time, u, v, w, theta, fx, fy, fz)
  integer, intent(in) :: n(3)
  real(rp), intent(in) :: time
  real(rp), intent(in) :: u(:,:,:), v(:,:,:), w(:,:,:), theta(:,:,:)
  real(rp), intent(out) :: fx(:,:,:), fy(:,:,:), fz(:,:,:)

  integer :: i,j,k
  real(rp) :: theta_u, theta_v, theta_w
  real(rp), parameter :: alpha = 1.0_rp

!$acc parallel loop collapse(3) present(u,v,w,theta,fx,fy,fz)
  do k=1,n(3)
    do j=1,n(2)
      do i=1,n(1)

        theta_u = theta(i,j,k)
        theta_v = theta(i,j,k)
        theta_w = theta(i,j,k)

        fx(i,j,k) = alpha * u(i,j,k) * theta_u
        fy(i,j,k) = alpha * v(i,j,k) * theta_v
        fz(i,j,k) = alpha * w(i,j,k) * theta_w

      end do
    end do
  end do
!$acc end parallel loop

end subroutine calc_bodyforce

end module mod_bodyforce
