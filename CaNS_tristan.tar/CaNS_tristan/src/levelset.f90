subroutine reinit_fls_godunov(n,dl,dli,dzf,dzci,fls)
  use mod_types, only: rp
  implicit none

  integer , intent(in) :: n(3)
  real(rp), intent(in) :: dl(3), dli(3)
  real(rp), intent(in) :: dzf(0:), dzci(0:)
  real(rp), intent(inout), dimension(0:,0:,0:) :: fls

  integer :: i,j,k, iter, nreinit
  real(rp) :: dtau, dmin, eps
  real(rp) :: phixm, phixp, phiym, phiyp, phizm, phizp
  real(rp) :: a, b, c, d, e, f
  real(rp) :: gradp, gradm, sphi
  real(rp), allocatable :: phi0(:,:,:), phin(:,:,:)

  nreinit = 20

  dmin = min(dl(1),dl(2),minval(dzf(1:n(3))))
  dtau = 0.3_rp*dmin
  eps  = 1.5_rp*dmin

  allocate(phi0(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(phin(0:n(1)+1,0:n(2)+1,0:n(3)+1))

  phi0 = fls
  phin = fls

  do iter=1,nreinit

    do k=1,n(3)
      do j=1,n(2)
        do i=1,n(1)

          phixm = (fls(i  ,j,k)-fls(i-1,j,k))*dli(1)
          phixp = (fls(i+1,j,k)-fls(i  ,j,k))*dli(1)

          phiym = (fls(i,j  ,k)-fls(i,j-1,k))*dli(2)
          phiyp = (fls(i,j+1,k)-fls(i,j  ,k))*dli(2)

          phizm = (fls(i,j,k  )-fls(i,j,k-1))*dzci(k)
          phizp = (fls(i,j,k+1)-fls(i,j,k  ))*dzci(k+1)

          a = max(phixm,0.0_rp)**2
          b = min(phixp,0.0_rp)**2
          c = max(phiym,0.0_rp)**2
          d = min(phiyp,0.0_rp)**2
          e = max(phizm,0.0_rp)**2
          f = min(phizp,0.0_rp)**2

          gradp = sqrt(max(a,b) + max(c,d) + max(e,f))

          a = min(phixm,0.0_rp)**2
          b = max(phixp,0.0_rp)**2
          c = min(phiym,0.0_rp)**2
          d = max(phiyp,0.0_rp)**2
          e = min(phizm,0.0_rp)**2
          f = max(phizp,0.0_rp)**2

          gradm = sqrt(max(a,b) + max(c,d) + max(e,f))

          sphi = phi0(i,j,k)/sqrt(phi0(i,j,k)**2 + eps**2)

          if(sphi >= 0.0_rp) then
            phin(i,j,k) = fls(i,j,k) - dtau*sphi*(gradp - 1.0_rp)
          else
            phin(i,j,k) = fls(i,j,k) - dtau*sphi*(gradm - 1.0_rp)
          endif

        end do
      end do
    end do

    fls(1:n(1),1:n(2),1:n(3)) = phin(1:n(1),1:n(2),1:n(3))

    ! 必要ならここで境界条件を更新
    call update_fls_boundary(n,fls)

  end do

  deallocate(phi0,phin)

end subroutine reinit_fls_godunov

subroutine update_fls_boundary(n,fls)
  use mod_types, only: rp
  implicit none

  integer, intent(in) :: n(3)
  real(rp), intent(inout), dimension(0:,0:,0:) :: fls
  integer :: i,j,k

  ! x periodic
  fls(0      ,:,:) = fls(n(1),:,:)
  fls(n(1)+1,:,:) = fls(1   ,:,:)

  ! y periodic
  fls(:,0      ,:) = fls(:,n(2),:)
  fls(:,n(2)+1,:) = fls(:,1   ,:)

  ! z Neumann
  fls(:,:,0      ) = fls(:,:,1   )
  fls(:,:,n(3)+1 ) = fls(:,:,n(3))

end subroutine update_fls_boundary

subroutine update_flv_from_fls(n,dl,pi,fls,flv)
  use mod_types, only: rp
  implicit none

  integer , intent(in) :: n(3)
  real(rp), intent(in) :: dl(3), pi
  real(rp), intent(in) :: fls(0:,0:,0:)
  real(rp), intent(inout) :: flv(0:,0:,0:)

  integer :: i,j,k
  real(rp) :: dgr

  dgr = 2.0_rp*sqrt(dl(1)**2 + dl(2)**2)

  do k=0,n(3)+1
    do j=0,n(2)+1
      do i=0,n(1)+1
        if(fls(i,j,k) < -0.5_rp*dgr) then
          flv(i,j,k) = 0.0_rp
        else if(fls(i,j,k) > 0.5_rp*dgr) then
          flv(i,j,k) = 1.0_rp
        else
          flv(i,j,k) = 0.5_rp*(sin(pi*fls(i,j,k)/dgr) + 1.0_rp)
        end if
      end do
    end do
  end do

end subroutine update_flv_from_fls
