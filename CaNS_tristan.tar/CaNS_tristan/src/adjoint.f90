module mod_adjoint
  use mod_types
  use mod_common_mpi
  use mod_param, only: re
  use mod_fillps , only: fillps
  use mod_correc , only: correc
  use mod_bound  , only: boundp, bounduvw, updt_rhs_b
!  use mod_solver , only: solver
  use iso_c_binding, only: C_PTR
  use mod_types          , only: rp
  use mod_solve_helmholtz, only: solve_helmholtz, rhs_bound
  use mod_solver_gpu, only: solver_gpu
  use mod_param, only: re, is_fringe, fringe, inv_tau_fringe
  implicit none

contains

subroutine adjoint_solver(n,u,v,w,p,dt,nstep,dli,flv,fls,dzci,dzfi, &
                          rkcoeff, ng,dl,dzc,dzf, &
                          cbcpre,bcpre,cbcvel,bcvel, &
                          nb,is_bound, &
                          arrplanp,normfftp,lambdaxyp, &
                          ap,bp,cp, &
                          rhsbp,is_ptdma_update_p,ap_d,cp_d, &
                          is_impdiff,visc,hi, &
                          arrplanu,normfftu,lambdaxyu,au,bu,cu,rhsbu, &
                          arrplanv,normfftv,lambdaxyv,av,bv,cv,rhsbv, &
                          arrplanw,normfftw,lambdaxyw,aw,bw,cw,rhsbw, &
                          time,st3,tstat)

  use iso_c_binding, only: C_PTR
  use mod_solve_helmholtz, only: rhs_bound

  implicit none

  integer, intent(in) :: ng(3)
  integer, intent(in) :: nb(2,3)
  real(rp), intent(in) :: dl(3)
  real(rp), intent(in) :: dzc(0:)
  real(rp), intent(in) :: dzf(0:)
  character(len=1), intent(in) :: cbcpre(0:1,3)
  character(len=1), intent(in) :: cbcvel(0:1,3,3)
  real(rp), intent(in) :: bcpre(0:1,3)
  real(rp), intent(in) :: bcvel(0:1,3,3)
  logical, intent(in) :: is_bound(0:1,3)
  real(rp), intent(in) :: time
  real(rp), intent(in) :: rkcoeff(3,3)
#if !defined(_USE_HIP)
  integer, intent(in), dimension(2,2) :: arrplanp
#else
  type(C_PTR), intent(in), dimension(2,2) :: arrplanp
#endif
  real(rp), intent(in) :: normfftp
  real(rp), intent(in) :: lambdaxyp(:,:)
  real(rp), intent(in) :: ap(:), bp(:), cp(:)
  real(rp), intent(inout) :: ap_d(:,:,:), cp_d(:,:,:)
  logical, intent(inout) :: is_ptdma_update_p
  type(rhs_bound), intent(inout) :: rhsbp
  type(rhs_bound), intent(inout) :: rhsbu, rhsbv, rhsbw

  logical, intent(in) :: is_impdiff
  real(rp), intent(in) :: visc
  real(rp) :: alpha
  integer, intent(in), dimension(3) :: hi
#if !defined(_USE_HIP)
  integer, intent(in), dimension(2,2) :: arrplanu, arrplanv, arrplanw
#else
  type(C_PTR), intent(in), dimension(2,2) :: arrplanu, arrplanv, arrplanw
#endif
  real(rp), intent(in) :: normfftu, normfftv, normfftw
  real(rp), intent(in) :: lambdaxyu(:,:), lambdaxyv(:,:), lambdaxyw(:,:)

  real(rp), intent(in) :: au(:), bu(:), cu(:)
  real(rp), intent(in) :: av(:), bv(:), cv(:)
  real(rp), intent(in) :: aw(:), bw(:), cw(:)

  integer, intent(in) :: n(3)
  integer, intent(in) :: nstep
  real(rp), intent(in) :: dt
  real(rp), intent(in) :: dli(3)
  real(rp), intent(in) :: dzci(0:)
  real(rp), intent(in) :: dzfi(0:)

  real(rp), intent(in) :: u(0:,0:,0:)
  real(rp), intent(in) :: v(0:,0:,0:)
  real(rp), intent(in) :: w(0:,0:,0:)
  real(rp), intent(in) :: p(0:,0:,0:)
  real(rp), intent(in) :: flv(0:,0:,0:)
  real(rp), intent(in) :: fls(0:,0:,0:)
  
  real(rp), allocatable :: sens(:,:,:)
  real(rp), allocatable :: ub(:,:,:), vb(:,:,:), wb(:,:,:)
  real(rp), intent(in) :: st3(0:,0:,0:,:)
  real(rp), intent(in) :: tstat
  real(rp), allocatable :: ua(:,:,:), va(:,:,:), wa(:,:,:), pa(:,:,:)
  real(rp), allocatable :: duadt(:,:,:), dvadt(:,:,:), dwadt(:,:,:)
  real(rp), allocatable :: duadtk(:,:,:), dvadtk(:,:,:), dwadtk(:,:,:)
  character(len=1) :: cbcadjvel(0:1,3,3)
  real(rp) :: bcadjvel(0:1,3,3)

  integer :: i,j,k,istep,irk
  integer :: nadj_step
  real(rp) :: factor1, factor2
  real(rp) :: dtrk
  real(rp) :: eta_vpm, denom
  real(rp) :: sens_sum

  eta_vpm = 1.0e4_rp


  if(myid == 0) then
    write(*,*) '====================================='
    write(*,*) 'Adjoint solver starts'
    write(*,*) '====================================='
    call flush(6)
  endif

  allocate(ua(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(va(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(wa(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(pa(0:n(1)+1,0:n(2)+1,0:n(3)+1))

  allocate(duadt(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(dvadt(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(dwadt(0:n(1)+1,0:n(2)+1,0:n(3)+1))

  allocate(duadtk(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(dvadtk(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(dwadtk(0:n(1)+1,0:n(2)+1,0:n(3)+1))

  allocate(ub(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(vb(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  allocate(wb(0:n(1)+1,0:n(2)+1,0:n(3)+1))

  !$acc enter data create(ub,vb,wb)
  !$acc enter data create(ua,va,wa,pa,duadt,dvadt,dwadt,duadtk,dvadtk,dwadtk)

  allocate(sens(0:n(1)+1,0:n(2)+1,0:n(3)+1))
  !$acc enter data create(sens)


  !$acc parallel loop collapse(3) default(present)
  do k=0,n(3)+1
    do j=0,n(2)+1
      do i=0,n(1)+1
        ua(i,j,k) = 0._rp
        va(i,j,k) = 0._rp
        wa(i,j,k) = 0._rp
        pa(i,j,k) = 0._rp

        duadt(i,j,k) = 0._rp
        dvadt(i,j,k) = 0._rp
        dwadt(i,j,k) = 0._rp

        duadtk(i,j,k) = 0._rp
        dvadtk(i,j,k) = 0._rp
        dwadtk(i,j,k) = 0._rp

        sens(i,j,k) = 0._rp
      end do
    end do
  end do
  !$acc end parallel loop

!cbcadjvel = cbcvel
!bcadjvel  = bcvel
!cbcadjvel(0:1,1:3,1) = reshape(['P','P','P','P','D','D'], [2,3])
!cbcadjvel(0:1,1:3,2) = reshape(['P','P','P','P','D','D'], [2,3])
!cbcadjvel(0:1,1:3,3) = reshape(['P','P','P','P','D','D'], [2,3])
!bcadjvel(0:1,1:3,1) = reshape([0._rp,0._rp, 0._rp,0._rp, 0._rp,0._rp], [2,3])
!bcadjvel(0:1,1:3,2) = reshape([0._rp,0._rp, 0._rp,0._rp, 0._rp,0._rp], [2,3])
!bcadjvel(0:1,1:3,3) = reshape([0._rp,0._rp, 0._rp,0._rp, 0._rp,0._rp], [2,3])

  call set_adjoint_terminal(n,u,v,w,ua,va,wa)

  !$acc parallel loop collapse(3) default(present)
  do k=0,n(3)+1
    do j=0,n(2)+1
      do i=0,n(1)+1
        ub(i,j,k) = st3(i,j,k,1)/tstat
        vb(i,j,k) = st3(i,j,k,2)/tstat
        wb(i,j,k) = st3(i,j,k,3)/tstat
      end do
    end do
  end do
  !$acc end parallel loop

  ! デバッグ用。まずは10ステップだけ。
  nadj_step = min(nstep,10)

  do istep = nadj_step, 1, -1

    if(myid == 0) then
      write(*,*) 'Adjoint time step = ', istep
      call flush(6)
    endif

    ! RK old RHS should be reset at the beginning of each physical adjoint time step
    !$acc parallel loop collapse(3) default(present)
    do k=0,n(3)+1
      do j=0,n(2)+1
        do i=0,n(1)+1
          duadtk(i,j,k) = 0._rp
          dvadtk(i,j,k) = 0._rp
          dwadtk(i,j,k) = 0._rp
        end do
      end do
    end do
    !$acc end parallel loop

    do irk = 1,3
      factor1 = rkcoeff(1,irk)*dt
      factor2 = rkcoeff(2,irk)*dt
      dtrk    = sum(rkcoeff(:,irk))*dt

      !$acc parallel loop collapse(3) default(present)
      do k=1,n(3)
        do j=1,n(2)
          do i=1,n(1)
            duadt(i,j,k) = 0._rp
            dvadt(i,j,k) = 0._rp
            dwadt(i,j,k) = 0._rp
          end do
        end do
      end do
      !$acc end parallel loop

      call compute_adjoint_rhs(n,ub,vb,wb,ua,va,wa,duadt,dvadt,dwadt,dli,dzci,dzfi,eta_vpm,flv)

      !$acc parallel loop collapse(3) default(present) private(denom)
      do k=1,n(3)
        do j=1,n(2)
          do i=1,n(1)
            denom = 1._rp + factor1*eta_vpm*flv(i,j,k)
            if(is_fringe) denom = denom + factor1*fringe(i)*inv_tau_fringe
            ua(i,j,k) = (ua(i,j,k) - factor1*duadt(i,j,k) - factor2*duadtk(i,j,k)) / denom
            va(i,j,k) = (va(i,j,k) - factor1*dvadt(i,j,k) - factor2*dvadtk(i,j,k)) / denom
            wa(i,j,k) = (wa(i,j,k) - factor1*dwadt(i,j,k) - factor2*dwadtk(i,j,k)) / denom

            duadtk(i,j,k) = duadt(i,j,k)
            dvadtk(i,j,k) = dvadt(i,j,k)
            dwadtk(i,j,k) = dwadt(i,j,k)

          end do
        end do
      end do
      !$acc end parallel loop
!      call bounduvw_adjoint(n,ua,va,wa)
      call bounduvw(cbcadjvel,n,bcvel,nb,is_bound,.true.,dl,dzc,dzf,ua,va,wa,time)
! ---- implicit diffusion / Crank-Nicolson ----
      if(is_impdiff) then
       alpha = -0.5_rp*visc*dtrk
       call solve_helmholtz(n,ng,hi,arrplanu,normfftu,alpha, &
                       lambdaxyu,au,bu,cu,rhsbu%x,rhsbu%y,rhsbu%z, &
                       is_bound,cbcadjvel(:,:,1),['f','c','c'],ua)
       call solve_helmholtz(n,ng,hi,arrplanv,normfftv,alpha, &
                       lambdaxyv,av,bv,cv,rhsbv%x,rhsbv%y,rhsbv%z, &
                       is_bound,cbcvel(:,:,2),['c','f','c'],va)
       call solve_helmholtz(n,ng,hi,arrplanw,normfftw,alpha, &
                       lambdaxyw,aw,bw,cw,rhsbw%x,rhsbw%y,rhsbw%z, &
                       is_bound,cbcvel(:,:,3),['c','c','f'],wa)
      endif
      call bounduvw(cbcadjvel,n,bcadjvel,nb,is_bound,.true.,dl,dzc,dzf,ua,va,wa,time)

call check_adjoint(n,dli,dzfi,ua,va,wa)  ! projection前
      call adjoint_projection(n,ng,dli,dzci,dzfi,dl,dzc,dzf, &
                        ua,va,wa,pa,dtrk, &
                        cbcpre,bcpre,cbcvel,bcvel,nb,is_bound, &
                        arrplanp,normfftp,lambdaxyp,ap,bp,cp, &
                        rhsbp,is_ptdma_update_p,ap_d,cp_d,time)
      call bounduvw(cbcvel,n,bcvel,nb,is_bound,.true.,dl,dzc,dzf,ua,va,wa,time)
! ここで感度蓄積
      !$acc parallel loop collapse(3) default(present)
      do k=1,n(3)
        do j=1,n(2)
          do i=1,n(1)
           sens(i,j,k) = sens(i,j,k) + ua(i,j,k)*ub(i,j,k)*dtrk
          end do
        end do
      end do
      !$acc end parallel loop

    end do
    call check_adjoint(n,dli,dzfi,ua,va,wa)
  end do

  !$acc update host(sens)
  sens_sum = sum(sens(1:n(1),1:n(2),1:n(3)))
  if(myid == 0) then
    write(*,*) '====================================='
    write(*,*) 'Sensitivity check'
    write(*,*) 'sens min = ', minval(sens(1:n(1),1:n(2),1:n(3)))
    write(*,*) 'sens max = ', maxval(sens(1:n(1),1:n(2),1:n(3)))
    write(*,*) 'sens sum = ', sens_sum
    write(*,*) '====================================='
    call flush(6)
  endif

  !$acc exit data delete(ua,va,wa,pa,duadt,dvadt,dwadt,duadtk,dvadtk,dwadtk)

  if(myid == 0) then
    write(*,*) '====================================='
    write(*,*) 'Adjoint solver ends'
    write(*,*) '====================================='
    call flush(6)
  endif
  !$acc exit data delete(ub,vb,wb,sens)
  deallocate(ub,vb,wb)
  deallocate(ua,va,wa,pa,sens)
  deallocate(duadt,dvadt,dwadt)
  deallocate(duadtk,dvadtk,dwadtk)

end subroutine adjoint_solver


subroutine set_adjoint_terminal(n,u,v,w,ua,va,wa)
  implicit none

  integer, intent(in) :: n(3)

  real(rp), intent(in) :: u(0:,0:,0:)
  real(rp), intent(in) :: v(0:,0:,0:)
  real(rp), intent(in) :: w(0:,0:,0:)

  real(rp), intent(inout) :: ua(0:,0:,0:)
  real(rp), intent(inout) :: va(0:,0:,0:)
  real(rp), intent(inout) :: wa(0:,0:,0:)

  integer :: i,j,k

  !$acc parallel loop collapse(3) default(present)
  do k=0,n(3)+1
    do j=0,n(2)+1
      do i=0,n(1)+1
        ua(i,j,k) = 0._rp
        va(i,j,k) = 0._rp
        wa(i,j,k) = 0._rp
      end do
    end do
  end do
  !$acc end parallel loop

end subroutine set_adjoint_terminal


subroutine compute_adjoint_rhs(n,u,v,w,ua,va,wa,duadt,dvadt,dwadt,dli,dzci,dzfi,eta_vpm,flv)
  implicit none

  integer, intent(in) :: n(3)
  real(rp), intent(in) :: dli(3)
  real(rp), intent(in) :: dzci(0:)
  real(rp), intent(in) :: dzfi(0:)

  real(rp), intent(in) :: u(0:,0:,0:)
  real(rp), intent(in) :: v(0:,0:,0:)
  real(rp), intent(in) :: w(0:,0:,0:)

  real(rp), intent(in) :: ua(0:,0:,0:)
  real(rp), intent(in) :: va(0:,0:,0:)
  real(rp), intent(in) :: wa(0:,0:,0:)

  real(rp), intent(in) :: flv(0:,0:,0:)

  real(rp), intent(inout) :: duadt(0:,0:,0:)
  real(rp), intent(inout) :: dvadt(0:,0:,0:)
  real(rp), intent(inout) :: dwadt(0:,0:,0:)

  integer :: i,j,k

  real(rp) :: dudx,dudy,dudz
  real(rp) :: dvdx,dvdy,dvdz
  real(rp) :: dwdx,dwdy,dwdz

  real(rp) :: duadx,duady,duadz
  real(rp) :: dvadx,dvady,dvadz
  real(rp) :: dwadx,dwady,dwadz

  real(rp) :: div_ua, div_va, div_wa
  real(rp) :: uuip, uuim, vujp, vujm, wukp, wukm
  real(rp) :: uvip, uvim, vvjp, vvjm, wvkp, wvkm
  real(rp) :: uwip, uwim, vwjp, vwjm, wwkp, wwkm
  real(rp) :: dudx_u, dvdx_u, dwdx_u
  real(rp) :: dudy_v, dvdy_v, dwdy_v
  real(rp) :: dudz_w, dvdz_w, dwdz_w

  real(rp) :: lapx, lapy, lapz
  real(rp) :: lap_ua, lap_va, lap_wa
  real(rp) :: nu
  real(rp) :: eta_vpm

  nu = 1._rp/re

  !$acc parallel loop collapse(3) default(present) private( &
  !$acc uuip,uuim,vujp,vujm,wukp,wukm, &
  !$acc uvip,uvim,vvjp,vvjm,wvkp,wvkm, &
  !$acc uwip,uwim,vwjp,vwjm,wwkp,wwkm, &
  !$acc dudx_u,dvdx_u,dwdx_u, &
  !$acc dudy_v,dvdy_v,dwdy_v, &
  !$acc dudz_w,dvdz_w,dwdz_w, &
  !$acc div_ua,div_va,div_wa)
  do k=1,n(3)
    do j=1,n(2)
      do i=1,n(1)
          uuip = 0.25*( u(i,j  ,k  )+u(i+1,j  ,k  ) )*( ua(i,j,k)+ua(i+1,j,k) )
          uuim = 0.25*( u(i,j  ,k  )+u(i-1,j  ,k  ) )*( ua(i,j,k)+ua(i-1,j,k) )
          vujp = 0.25*( v(i,j  ,k  )+v(i+1,j  ,k  ) )*( ua(i,j,k)+ua(i,j+1,k) )
          vujm = 0.25*( v(i,j-1,k  )+v(i+1,j-1,k  ) )*( ua(i,j,k)+ua(i,j-1,k) )
          wukp = 0.25*( w(i,j  ,k  )+w(i+1,j  ,k  ) )*( ua(i,j,k)+ua(i,j,k+1) )
          wukm = 0.25*( w(i,j  ,k-1)+w(i+1,j  ,k-1) )*( ua(i,j,k)+ua(i,j,k-1) )
          uvip = 0.25*( u(i  ,j,k  )+u(i  ,j+1,k  ) )*( va(i,j,k)+va(i+1,j,k) )
          uvim = 0.25*( u(i-1,j,k  )+u(i-1,j+1,k  ) )*( va(i,j,k)+va(i-1,j,k) )
          vvjp = 0.25*( v(i  ,j,k  )+v(i  ,j+1,k  ) )*( va(i,j,k)+va(i,j+1,k) )
          vvjm = 0.25*( v(i  ,j,k  )+v(i  ,j-1,k  ) )*( va(i,j,k)+va(i,j-1,k) )
          wvkp = 0.25*( w(i  ,j,k  )+w(i  ,j+1,k  ) )*( va(i,j,k)+va(i,j,k+1) )
          wvkm = 0.25*( w(i  ,j,k-1)+w(i  ,j+1,k-1) )*( va(i,j,k)+va(i,j,k-1) )
          uwip = 0.25*( u(i  ,j  ,k)+u(i  ,j  ,k+1) )*( wa(i,j,k)+wa(i+1,j,k) )
          uwim = 0.25*( u(i-1,j  ,k)+u(i-1,j  ,k+1) )*( wa(i,j,k)+wa(i-1,j,k) )
          vwjp = 0.25*( v(i  ,j  ,k)+v(i  ,j  ,k+1) )*( wa(i,j,k)+wa(i,j+1,k) )
          vwjm = 0.25*( v(i  ,j-1,k)+v(i  ,j-1,k+1) )*( wa(i,j,k)+wa(i,j-1,k) )
          wwkp = 0.25*( w(i  ,j  ,k)+w(i  ,j  ,k+1) )*( wa(i,j,k)+wa(i,j,k+1) )
          wwkm = 0.25*( w(i  ,j  ,k)+w(i  ,j  ,k-1) )*( wa(i,j,k)+wa(i,j,k-1) )
! ---- adjoint convection: flux-divergence part ----
        div_ua = &
                 (-uuip + uuim) *dli(1) &
         +       (-vujp + vujm) *dli(2) &
         +       (-wukp + wukm) *dzfi(k)
        div_va = &
                 (-uvip + uvim) *dli(1) &
         +       (-vvjp + vvjm) *dli(2) &
         +       (-wvkp + wvkm) *dzfi(k)
        div_wa = &
                 (-uwip + uwim) *dli(1) &
         +       (-vwjp + vwjm) *dli(2) &
         +       (-wwkp + wwkm) *dzfi(k)

        dudx_u = (u(i+1,j,k)-u(i,j,k))*dli(1)
        dvdx_u = 0.25_rp*( &
                 (v(i+1,j  ,k)-v(i  ,j  ,k))*dli(1) + &
                 (v(i+1,j-1,k)-v(i  ,j-1,k))*dli(1) + &
                 (v(i+1,j+1,k)-v(i  ,j+1,k))*dli(1) + &
                 (v(i+1,j  ,k)-v(i  ,j  ,k))*dli(1) )
        dwdx_u = 0.25_rp*( &
                 (w(i+1,j,k  )-w(i,j,k  ))*dli(1) + &
                 (w(i+1,j,k-1)-w(i,j,k-1))*dli(1) + &
                 (w(i+1,j,k+1)-w(i,j,k+1))*dli(1) + &
                 (w(i+1,j,k  )-w(i,j,k  ))*dli(1) )

        dudy_v = 0.25_rp*( &
                 (u(i  ,j+1,k)-u(i  ,j,k))*dli(2) + &
                 (u(i-1,j+1,k)-u(i-1,j,k))*dli(2) + &
                 (u(i+1,j+1,k)-u(i+1,j,k))*dli(2) + &
                 (u(i  ,j+1,k)-u(i  ,j,k))*dli(2) )
        dvdy_v = (v(i,j+1,k)-v(i,j,k))*dli(2)
        dwdy_v = 0.25_rp*( &
                 (w(i,j+1,k  )-w(i,j,k  ))*dli(2) + &
                 (w(i,j+1,k-1)-w(i,j,k-1))*dli(2) + &
                 (w(i,j+1,k+1)-w(i,j,k+1))*dli(2) + &
                 (w(i,j+1,k  )-w(i,j,k  ))*dli(2) )

        dudz_w = 0.25_rp*( &
                 (u(i  ,j,k+1)-u(i  ,j,k))*dzfi(k) + &
                 (u(i-1,j,k+1)-u(i-1,j,k))*dzfi(k) + &
                 (u(i+1,j,k+1)-u(i+1,j,k))*dzfi(k) + &
                 (u(i  ,j,k+1)-u(i  ,j,k))*dzfi(k) )
        dvdz_w = 0.25_rp*( &
                 (v(i,j  ,k+1)-v(i,j  ,k))*dzfi(k) + &
                 (v(i,j-1,k+1)-v(i,j-1,k))*dzfi(k) + &
                 (v(i,j+1,k+1)-v(i,j+1,k))*dzfi(k) + &
                 (v(i,j  ,k+1)-v(i,j  ,k))*dzfi(k) )
        dwdz_w = (w(i,j,k+1)-w(i,j,k))*dzfi(k)


        duadt(i,j,k) = duadt(i,j,k) + div_ua &
             + dudx_u*ua(i,j,k) &
             + dvdx_u*0.25_rp*(va(i+1,j,k)+va(i,j,k)+va(i,j-1,k)+va(i+1,j-1,k))&
             + dwdx_u*0.25_rp*(wa(i,j,k)+wa(i+1,j,k)+wa(i,j,k-1)+wa(i+1,j,k-1)) 
        dvadt(i,j,k) = dvadt(i,j,k) + div_va &
             + dudy_v*0.25_rp*(ua(i,j,k)+ua(i,j+1,k)+ua(i-1,j+1,k)+ua(i,j-1,k))& 
             + dvdy_v*va(i,j,k) &
             + dwdy_v*0.25_rp*(wa(i,j,k)+wa(i,j+1,k)+wa(i,j+1,k-1)+wa(i,j,k-1))
        dwadt(i,j,k) = dwadt(i,j,k) + div_wa &
             + dudz_w*0.25_rp*(ua(i,j,k)+ua(i,j,k+1)+ua(i-1,j,k)+ua(i-1,j,k+1))& 
             + dvdz_w*0.25_rp*(va(i,j,k)+va(i,j,k+1)+va(i,j-1,k+1)+va(i,j-1,k)) &
             + dwdz_w*wa(i,j,k)


       ! from cost functional
        duadt(i,j,k) =duadt(i,j,k) + 1.0e-4_rp*(1._rp-flv(i,j,k))
        dvadt(i,j,k) =dvadt(i,j,k) + 0._rp
        dwadt(i,j,k) =dwadt(i,j,k) + 0._rp

      end do
    end do
  end do
  !$acc end parallel loop

end subroutine compute_adjoint_rhs


subroutine adjoint_projection(n,ng,dli,dzci,dzfi,dl,dzc,dzf, &
                              ua,va,wa,pa,dtrk, &
                              cbcpre,bcpre,cbcvel,bcvel,nb,is_bound, &
                              arrplanp,normfftp,lambdaxyp,ap,bp,cp, &
                              rhsbp,is_ptdma_update_p,ap_d,cp_d,time)
                           
  use mpi
  implicit none
  integer :: ierr
  integer, intent(in) :: n(3), ng(3), nb(2,3)
  real(rp), intent(in) :: dli(3), dl(3)
  real(rp), intent(in) :: dzci(0:), dzfi(0:)
  real(rp), intent(in) :: dzc(0:), dzf(0:)
  real(rp), intent(in) :: dtrk
  real(rp), intent(in) :: time

  character(len=1), intent(in) :: cbcpre(0:1,3)
  character(len=1), intent(in) :: cbcvel(0:1,3,3)

  real(rp), intent(in) :: bcpre(0:1,3)
  real(rp), intent(in) :: bcvel(0:1,3,3)

  logical, intent(in) :: is_bound(0:1,3)

  real(rp), intent(inout) :: ua(0:,0:,0:)
  real(rp), intent(inout) :: va(0:,0:,0:)
  real(rp), intent(inout) :: wa(0:,0:,0:)
  real(rp), intent(inout) :: pa(0:,0:,0:)

#if !defined(_USE_HIP)
  integer, intent(in), dimension(2,2) :: arrplanp
#else
  type(C_PTR), intent(in), dimension(2,2) :: arrplanp
#endif
  real(rp), intent(in) :: normfftp
  real(rp), intent(in) :: lambdaxyp(:,:)
  real(rp), intent(in) :: ap(:), bp(:), cp(:)
  real(rp), intent(inout) :: ap_d(:,:,:), cp_d(:,:,:)
  type(rhs_bound), intent(inout) :: rhsbp
  logical, intent(inout) :: is_ptdma_update_p

  real(rp) :: dtrki

  character(len=1) :: cbcadjpre(0:1,3)
  real(rp) :: bcadjpre(0:1,3)

if(myid == 0) then
  write(*,*) 'adjoint_projection dtrk=', dtrk
  call flush(6)
endif
if(abs(dtrk) < 1.0e-30_rp) then
  if(myid == 0) write(*,*) 'ERROR: dtrk is zero'
  call MPI_ABORT(MPI_COMM_WORLD,1,ierr)
endif

  dtrki = 1._rp/dtrk
  cbcadjpre = cbcpre
  bcadjpre  = bcpre
!  ! adjoint pressure BC
!  ! x,y は周期のまま
!  cbcadjpre(0,1) = 'P'
!  cbcadjpre(1,1) = 'P'
!  cbcadjpre(0,2) = 'P'
!  cbcadjpre(1,2) = 'P'
!  ! z は Neumann-Neumann にする場合
!  cbcadjpre(0,3) = 'N'
!  cbcadjpre(1,3) = 'N'
!  bcadjpre(0,3)  = 0._rp
!  bcadjpre(1,3)  = 0._rp

  call fillps(n,dli,dzfi,dtrki,ua,va,wa,pa)
  call updt_rhs_b(['c','c','c'],cbcpre,n,is_bound, &
                rhsbp%x,rhsbp%y,rhsbp%z,pa)
  call solver_gpu(n,ng,arrplanp,normfftp,lambdaxyp,ap,bp,cp,cbcpre, &
                ['c','c','c'],pa,is_ptdma_update_p,ap_d,cp_d)
  call boundp(cbcpre,n,bcpre,nb,is_bound,dl,dzc,pa)
  call correc(n,dli,dzci,dtrk,pa,ua,va,wa)
!  call bounduvw_adjoint(n,ua,va,wa)
  call bounduvw(cbcvel,n,bcvel,nb,is_bound,.true.,dl,dzc,dzf,ua,va,wa,time)

!$acc update host(pa)
if(myid == 0) then
  write(*,*) 'pa min/max = ', minval(pa), maxval(pa)
endif

end subroutine adjoint_projection

subroutine bounduvw_adjoint(n,ua,va,wa)
  implicit none

  integer, intent(in) :: n(3)
  real(rp), intent(inout) :: ua(0:,0:,0:)
  real(rp), intent(inout) :: va(0:,0:,0:)
  real(rp), intent(inout) :: wa(0:,0:,0:)

  integer :: i,j,k

  !$acc parallel loop collapse(2) default(present)
  do k=0,n(3)+1
    do j=0,n(2)+1
      ua(0,j,k)      = ua(n(1),j,k)
      ua(n(1)+1,j,k) = ua(1,j,k)

      va(0,j,k)      = va(n(1),j,k)
      va(n(1)+1,j,k) = va(1,j,k)

      wa(0,j,k)      = wa(n(1),j,k)
      wa(n(1)+1,j,k) = wa(1,j,k)
    end do
  end do
  !$acc end parallel loop

  !$acc parallel loop collapse(2) default(present)
  do k=0,n(3)+1
    do i=0,n(1)+1
      ua(i,0,k)      = ua(i,n(2),k)
      ua(i,n(2)+1,k) = ua(i,1,k)

      va(i,0,k)      = va(i,n(2),k)
      va(i,n(2)+1,k) = va(i,1,k)

      wa(i,0,k)      = wa(i,n(2),k)
      wa(i,n(2)+1,k) = wa(i,1,k)
    end do
  end do
  !$acc end parallel loop

  !$acc parallel loop collapse(2) default(present)
  do j=0,n(2)+1
    do i=0,n(1)+1
      ua(i,j,0)      = 0._rp
      ua(i,j,n(3)+1) = 0._rp

      va(i,j,0)      = 0._rp
      va(i,j,n(3)+1) = 0._rp

      wa(i,j,0)      = 0._rp
      wa(i,j,n(3)  ) = 0._rp
    end do
  end do
  !$acc end parallel loop

end subroutine bounduvw_adjoint

subroutine check_adjoint(n,dli,dzfi,ua,va,wa)
  implicit none

  integer, intent(in) :: n(3)
  real(rp), intent(in) :: dli(3), dzfi(0:)
  real(rp), intent(in) :: ua(0:,0:,0:)
  real(rp), intent(in) :: va(0:,0:,0:)
  real(rp), intent(in) :: wa(0:,0:,0:)

  integer :: i,j,k
  real(rp) :: divloc, divmax

  divmax = 0._rp

  !$acc update host(ua,va,wa)

  do k=1,n(3)
    do j=1,n(2)
      do i=1,n(1)
        divloc = abs( &
          (ua(i,j,k)-ua(i-1,j,k))*dli(1) + &
          (va(i,j,k)-va(i,j-1,k))*dli(2) + &
          (wa(i,j,k)-wa(i,j,k-1))*dzfi(k) )
        divmax = max(divmax,divloc)
      end do
    end do
  end do

  if(myid == 0) then
    write(*,*) 'adjoint ua min/max = ', minval(ua), maxval(ua)
    write(*,*) 'adjoint va min/max = ', minval(va), maxval(va)
    write(*,*) 'adjoint wa min/max = ', minval(wa), maxval(wa)
    write(*,*) 'adjoint div max    = ', divmax
    call flush(6)
  endif

end subroutine check_adjoint

end module mod_adjoint
